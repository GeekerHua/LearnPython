CREATE VIEW `v_stu_cls` AS
  SELECT
    `python3`.`t_students`.`id`   AS `id`,
    `python3`.`t_students`.`name` AS `name`,
    `python3`.`t_classes`.`name`  AS `title`
  FROM (`python3`.`t_students`
    JOIN `python3`.`t_classes` ON ((`python3`.`t_classes`.`id` = `python3`.`t_students`.`classid`)))