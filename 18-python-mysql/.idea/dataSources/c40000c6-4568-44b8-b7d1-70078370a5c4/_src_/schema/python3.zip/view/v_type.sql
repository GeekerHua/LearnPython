CREATE VIEW `v_type` AS
  SELECT
    `sun`.`id`   AS `id`,
    `sun`.`name` AS `name`,
    `sun`.`pid`  AS `pid`
  FROM (`python3`.`t_type` `father`
    JOIN `python3`.`t_type` `sun` ON ((`father`.`id` = `sun`.`pid`)))