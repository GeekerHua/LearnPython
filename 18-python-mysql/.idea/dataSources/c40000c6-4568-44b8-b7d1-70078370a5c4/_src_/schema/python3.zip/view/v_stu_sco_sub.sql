CREATE VIEW `v_stu_sco_sub` AS
  SELECT
    `python3`.`students`.`name`  AS `name`,
    `python3`.`scores`.`score`   AS `score`,
    `python3`.`subjects`.`title` AS `title`
  FROM ((`python3`.`scores`
    JOIN `python3`.`students` ON ((`python3`.`students`.`id` = `python3`.`scores`.`stuid`))) JOIN `python3`.`subjects`
      ON ((`python3`.`subjects`.`id` = `python3`.`scores`.`subid`)))